import React from 'react'

export default () => <div>My lazy-loaded component</div>
