# History app using Next.js

## How-to run on LOCAL
- `npm run dev` will standup both the frontend and backend

## How-to build for PROD
- `npm run build` Bundle JavaScript files, and pre-compile
